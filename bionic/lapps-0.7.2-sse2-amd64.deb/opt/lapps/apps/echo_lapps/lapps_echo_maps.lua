lapps_echo_maps={}
lapps_echo_maps.__index=lapps_echo_maps

lapps_echo_maps["keys"]=nljson.decode('{}');

lapps_echo_maps["logins"]=nljson.decode([[{
  "admin" : "admin",
  "guest" : "guest" 
}]]);

return lapps_echo_maps
